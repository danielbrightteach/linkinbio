export const gtag = (event: string, params: any) => {
  if (typeof window !== "undefined" && typeof window.gtag === "function") {
    window.gtag("event", event, params)
  } else {
    console.log("gtag not available", event, params)
  }
}
