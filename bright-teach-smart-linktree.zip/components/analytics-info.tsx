"use client"

import { Card } from "@/components/ui/card"
import { useEffect, useState } from "react"

interface AnalyticsData {
  source: string
  content: string
  timestamp: string
}

export function AnalyticsInfo() {
  const [currentVisit, setCurrentVisit] = useState<AnalyticsData | null>(null)

  useEffect(() => {
    const referrer = document.referrer.toLowerCase()
    const urlParams = new URLSearchParams(window.location.search)

    let source = "direct"
    let content = ""

    if (referrer.includes("tiktok.com")) {
      source = "tiktok"
      content = "bio"
    } else if (referrer.includes("instagram.com")) {
      source = "instagram"
      if (referrer.includes("stories")) content = "story"
      else if (referrer.includes("reel")) content = "reel"
      else content = "bio"
    } else if (referrer.includes("facebook.com")) {
      source = "facebook"
      content = referrer.includes("story") ? "story" : "page"
    }

    // Check for manual tracking parameters
    const customSource = urlParams.get("ref")
    const customContent = urlParams.get("content")

    if (customSource) {
      source = customSource
      content = customContent || content
    }

    setCurrentVisit({
      source,
      content,
      timestamp: new Date().toISOString(),
    })
  }, [])

  if (!currentVisit) return null

  return (
    <Card className="mt-4 p-3 bg-blue-50 border border-blue-200">
      <div className="text-xs text-blue-800">
        <p className="font-medium">📊 Analytics Tracking Active</p>
        <p>
          Source: <span className="font-mono">{currentVisit.source}</span>
        </p>
        {currentVisit.content && (
          <p>
            Content: <span className="font-mono">{currentVisit.content}</span>
          </p>
        )}
        <p className="text-blue-600 mt-1">All clicks will be tracked with UTM parameters</p>
      </div>
    </Card>
  )
}
